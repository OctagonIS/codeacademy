#Import all modules needed
import pandas as pd
import matplotlib.pyplot as plt
from scipy.stats import chi2_contingency

#SQL Query to create dataframe
'''
df = sql_query(
select visits.first_name,
    visits.last_name,
    visits.gender,
    visits.email,
    visits.visit_date,
    fitness_tests.fitness_test_date,
    applications.application_date,
    purchases.purchase_date
FROM visits
LEFT JOIN fitness_tests
    ON visits.first_name = fitness_tests.first_name
    AND visits.last_name = fitness_tests.last_name
    AND visits.email = fitness_tests.email
LEFT JOIN applications
    ON visits.first_name = applications.first_name
    AND visits.last_name = applications.last_name
    AND visits.email = applications.email
LEFT JOIN purchases
    ON visits.first_name = purchases.first_name
    AND visits.last_name = purchases.last_name
    AND visits.email = purchases.email
WHERE visits.visit_date >= '7-1-17')
'''

#Import dataframe
df = pd.read_csv('C:/Users/Gary.Cooper/Dropbox/Codeacademy/6. Capstone/dataframe.csv')
print df.head(10)

#Add ab_test_group column to dataframe
test_lambda = lambda x: 'B' \
    if pd.isnull(x) \
    else 'A'
df['ab_test_group'] = df.fitness_test_date.apply(test_lambda)
print df.head(10)

#Count number of participants in each test group
ab_counts = df.groupby(['ab_test_group']).first_name.count().reset_index()
print(ab_counts)

#Create Pie Chart of participants by test group
plt.figure(figsize=(14,8))
payment_method_names = ["Fitness Test", "No Fitness Test"]
payment_method_freqs = [2504, 2500]
pie_colors = ['#942825', '#595959'] 
patches, texts, autotexts = plt.pie(payment_method_freqs, colors = pie_colors, autopct='%0.1f%%')
for autotext in autotexts:
    autotext.set_color('white')
for autotext in autotexts:
    autotext.set_size(30)
for i, a in enumerate(autotexts):
    a.set_text("{:,}".format(payment_method_freqs[i]))
plt.axis('equal')
plt.legend(patches, payment_method_names, loc="best", prop={'size': 20})
plt.title("Visitors by Test Group", fontsize=40)
plt.savefig('C:/Users/Gary.Cooper/Dropbox/Codeacademy/6. Capstone/visitors_by_test_group.png')
plt.show()

#Add is_application column to dataframe
application_lambda = lambda x: 'No Application' \
    if pd.isnull(x) \
    else 'Application'
df['is_application'] = df.application_date.apply(application_lambda)
print df.head(10)

#Count number of applicants and non-applicants by test group
app_counts = df.groupby(['ab_test_group', 'is_application']).first_name.count().reset_index()
print(app_counts)

#Pivoted applicant data
app_pivot = app_counts.pivot(
    index = 'ab_test_group',
    columns = 'is_application',
    values = 'first_name').reset_index()
print(app_pivot)

#Add Total and Percent of Total columns to app_pivot
app_pivot['Total'] = app_pivot['Application'] + app_pivot['No Application']
app_pivot['Percent of Total'] = app_pivot['Application'] / app_pivot['Total']
print app_pivot

#Chi2 Contingency Test for Significant Difference of Application Rate Between Test Groups
data = [[250, 2254],
     [325, 2175]]
chi2, pval, dof, expected = chi2_contingency(data)
print 'Applicant Rate P-Value = ' + str('{0:.3f}'.format(pval))

#Add is_member column to dataframe
member_lambda = lambda x: 'Not Member' \
    if pd.isnull(x) \
    else 'Member'
df['is_member'] = df.purchase_date.apply(member_lambda)
print df.head(10)

#Create new dataframe consisting only of people who picked up an application
just_apps = df[df.is_application == 'Application'].reset_index()
print just_apps.head(10)

#Count number of members by test group among people who picked up an application
member_counts = just_apps.groupby(['ab_test_group', 'is_member']).first_name.count().reset_index()
member_pivot = member_counts.pivot(
    index = 'ab_test_group',
    columns = 'is_member',
    values = 'first_name').reset_index()
member_pivot['Total'] = member_pivot['Member'] + member_pivot['Not Member']
member_pivot['Percent Purchase'] = member_pivot['Member'] / member_pivot['Total']
print member_pivot

#Chi2 Contingency Test for Signifcant Difference of Applicant-Member conversion between test groups
data_2 = [[200, 50],
     [250, 75]]
chi2_2, pval_2, dof_2, expected_2 = chi2_contingency(data_2)
print 'Applicant-Member Conversion P-Value = ' + str('{0:.3f}'.format(pval_2))

#Count number of members and non-members by test group
final_counts = df.groupby(['ab_test_group', 'is_member']).first_name.count().reset_index()
final_pivot = final_counts.pivot(
    index = 'ab_test_group',
    columns = 'is_member',
    values = 'first_name').reset_index()
final_pivot['Total'] = final_pivot['Member'] + final_pivot['Not Member']
final_pivot['Percent Purchase'] = final_pivot['Member'] / final_pivot['Total']
print final_pivot

#Chi2 Contingency Test for Significant Difference in Acquiring Members between groups
data_3 = [[200, 2304],
     [250, 2250]]
chi2_3, pval_3, dof_3, expected_3 = chi2_contingency(data_3)
print 'Membership Rate P-Value = ' + str('{0:.3f}'.format(pval_3))

#Create variables from exisitng dataframes for bar graphs - ***Would love some feedback on how to do this more efficiently. In excel, I would use a vlookup or a match-index function so that the variable would auto-update if the underlying data updated. I couldn't figure out a similar method in Python***
vis_app_a = (app_counts[(app_counts.ab_test_group == 'A') & (app_counts.is_application == 'Application')].values.tolist())[0][2]
vis_not_app_a = (app_counts[(app_counts.ab_test_group == 'A') & (app_counts.is_application == 'No Application')].values.tolist())[0][2]
vis_app_conversion_a = (1.0*vis_app_a) / (vis_app_a + vis_not_app_a)

vis_app_b = (app_counts[(app_counts.ab_test_group == 'B') & (app_counts.is_application == 'Application')].values.tolist())[0][2]
vis_not_app_b = (app_counts[(app_counts.ab_test_group == 'B') & (app_counts.is_application == 'No Application')].values.tolist())[0][2]
vis_app_conversion_b = (1.0*vis_app_b) / (vis_app_b + vis_not_app_b)

app_pur_a = (member_counts[(member_counts.ab_test_group == 'A') & (member_counts.is_member == 'Member')].values.tolist())[0][2]
app_not_pur_a = (member_counts[(member_counts.ab_test_group == 'A') & (member_counts.is_member == 'Not Member')].values.tolist())[0][2]
app_pur_conversion_a = (1.0*app_pur_a) / (app_pur_a + app_not_pur_a)

app_pur_b = (member_counts[(member_counts.ab_test_group == 'B') & (member_counts.is_member == 'Member')].values.tolist())[0][2]
app_not_pur_b = (member_counts[(member_counts.ab_test_group == 'B') & (member_counts.is_member == 'Not Member')].values.tolist())[0][2]
app_pur_conversion_b = (1.0*app_pur_b) / (app_pur_b + app_not_pur_b)

vis_pur_a = (final_counts[(final_counts.ab_test_group == 'A') & (final_counts.is_member == 'Member')].values.tolist())[0][2]
vis_not_pur_a = (final_counts[(final_counts.ab_test_group == 'A') & (final_counts.is_member == 'Not Member')].values.tolist())[0][2]
vis_pur_conversion_a = (1.0*vis_pur_a) / (vis_pur_a + vis_not_pur_a)

vis_pur_b = (final_counts[(final_counts.ab_test_group == 'B') & (final_counts.is_member == 'Member')].values.tolist())[0][2]
vis_not_pur_b = (final_counts[(final_counts.ab_test_group == 'B') & (final_counts.is_member == 'Not Member')].values.tolist())[0][2]
vis_pur_conversion_b = (1.0*vis_pur_b) / (vis_pur_b + vis_not_pur_b)

#Visitors Who Submitted Application Bar Graph ***Would love some feedback on how I can get the font in these graphs to match the font I am using in my popwerpoint deck. I am using a custom font 'Prometo' - is it possible to pipe in a new font using matplotlib?
plt.figure(figsize=(12,9.6))
labels = ['Fitness Test', 'No Fitness Test']
bar_colors = ['#595959', '#942825']
ax = plt.subplot()
plt.bar(range(len(labels)),[vis_app_conversion_a, vis_app_conversion_b], color = bar_colors)
plt.title("Visitors Who Submitted Application", fontsize=30)
plt.xlabel("Test Group", fontsize=24)
plt.ylabel("Submitted Application", fontsize=24)
ax.set_xticks(range(len(labels)))
ax.set_xticklabels(labels, fontsize=24)
ax.set_yticks([0, 0.05, 0.10, 0.15, 0.20])
ax.set_yticklabels(['0%', '5%', '10%', '15%', '20%'], fontsize=24)

rects = ax.patches
for rect in rects:
    y_value = rect.get_height()
    x_value = rect.get_x() + rect.get_width() / 2
    space = 5
    va = 'bottom'
    label = '{:.2%}'.format(y_value)
    plt.annotate(
        label,                      
        (x_value, y_value),        
        xytext=(0, space),          
        textcoords="offset points", 
        ha='center',                
        va=va, fontsize=24)                      
 
plt.savefig('C:/Users/Gary.Cooper/Dropbox/Codeacademy/6. Capstone/visitors_submitted_app.png')                                   
plt.show()

#Applicants Who Purchased a Membership Bar Graph
plt.figure(figsize=(12,9.6))
ax = plt.subplot()
plt.bar(range(len(labels)),[app_pur_conversion_a, app_pur_conversion_b], color = bar_colors)
plt.title("Applicants Who Purchased Membership", fontsize=30)
plt.xlabel("Test Group", fontsize=24)
plt.ylabel("Purchased Membership", fontsize=24)
ax.set_xticks(range(len(labels)))
ax.set_xticklabels(labels, fontsize=24)
ax.set_yticks([0, 0.2, 0.4, 0.6, 0.8, 1.0])
ax.set_yticklabels(['0%', '20%', '40%', '60%', '80%', '100%'], fontsize=24)

rects = ax.patches
for rect in rects:
    y_value = rect.get_height()
    x_value = rect.get_x() + rect.get_width() / 2
    space = 5
    va = 'bottom'
    label = '{:.2%}'.format(y_value)
    plt.annotate(
        label,                      
        (x_value, y_value),        
        xytext=(0, space),          
        textcoords="offset points", 
        ha='center',                
        va=va, fontsize=24)   

plt.savefig('C:/Users/Gary.Cooper/Dropbox/Codeacademy/6. Capstone/applicants_purchased_mem.png')
plt.show()

#Visitors Who Purchased a Membership Bar Graph
plt.figure(figsize=(12,9.6))
ax = plt.subplot()
plt.bar(range(len(labels)),[vis_pur_conversion_a, vis_pur_conversion_b], color = bar_colors)
plt.title("Visitors Who Purchased Membership", fontsize=30)
plt.xlabel("Test Group", fontsize=24)
plt.ylabel("Purchased Membership", fontsize=24)
ax.set_xticks(range(len(labels)))
ax.set_xticklabels(labels, fontsize=24)
ax.set_yticks([0, 0.05, 0.10, 0.15, 0.20])
ax.set_yticklabels(['0%', '5%', '10%', '15%', '20%'], fontsize=24)

rects = ax.patches
for rect in rects:
    y_value = rect.get_height()
    x_value = rect.get_x() + rect.get_width() / 2
    space = 5
    va = 'bottom'
    label = '{:.2%}'.format(y_value)
    plt.annotate(
        label,                      
        (x_value, y_value),        
        xytext=(0, space),          
        textcoords="offset points", 
        ha='center',                
        va=va, fontsize=24)   

plt.savefig('C:/Users/Gary.Cooper/Dropbox/Codeacademy/6. Capstone/visitors_purchased_mem.png')
plt.show()